# download Confluent at 
# https://www.confluent.io/download/

# Extract and then run
bin/confluent start 

# to stop
bin/confluent stop

# to destroy
bin/confluent destroy